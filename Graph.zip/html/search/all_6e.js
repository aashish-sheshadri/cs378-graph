var searchData=
[
  ['num_5fedges',['num_edges',['../classGraph.html#a8762ff8f5b09fea3fdcfb92c2648336e',1,'Graph']]],
  ['num_5fvertices',['num_vertices',['../classGraph.html#a58495c0a2630da064db06001bbee4b83',1,'Graph']]]
];
